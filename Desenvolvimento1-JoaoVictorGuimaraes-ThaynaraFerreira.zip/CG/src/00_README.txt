Alguns detalhes sobre esta pasta:
* Quase todos os projetos são para linux (testado no Linux Mint 18.2)
* Os projetos 'windows*.cbp' devem ser usados por usuários Windows como base para todos os códigos.
* Para limpar a pasta (arquivo .depend e .layout) executar no terminal do linux:
  sh 00_cleanup.sh
