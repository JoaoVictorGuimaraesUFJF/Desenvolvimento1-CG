#!/bin/bash
rm *.depend
rm *.layout
